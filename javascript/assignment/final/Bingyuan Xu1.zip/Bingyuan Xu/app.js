let shuffle = function (array) {
  let currentIndex = array.length, temporaryValue, randomIndex;

  while (currentIndex !== 0) {
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }

  return array;
};

function iconNameArray() {
  const iconCollection = document.querySelectorAll(`.card i`);
  const iconNames = Array.from(iconCollection);
  return shuffle(iconNames.map(ele => ele.className));
}

function reset() {
  for (let card of cardCollection) {
    card.className = `card`;
  }

  shuffleCards();
  turnsNum = 0;
  iconNameArrayIndex = 0;
  clickable = true;
  totalTurnsNum.textContent = `Total Turns: 0`;
  nextCardIcon.textContent = ``;
  nextCardIcon.className = iconNames[0];
}

function shuffleCards() {
  const cardElementArray = Array.from(cardCollection);
  shuffle(cardElementArray);
  cardsBox.innerHTML = ``;
  cardElementArray.forEach(ele => cardsBox.append(ele));
}

function clickSound() {
  const sound = document.querySelector(`audio`);
  sound.cloneNode().play();
}

const cardsBox = document.querySelector(`#cards`);
const totalTurnsNum = document.querySelector(`.score-container`);
const restartButton = document.querySelector(`.restart`);
const cardCollection = document.querySelectorAll(`.card`);
const nextCardIcon = document.querySelector(`#next-card i`);
const iconNames = iconNameArray();
let iconNameArrayIndex = 0;
let turnsNum = 0;
let clickable = true;

reset();

restartButton.addEventListener(`click`, reset);

cardsBox.addEventListener(`click`, function (element) {
  if (
    element.target.nodeName === `LI` &&
    !element.target.classList.contains(`matched`) &&
    clickable  //check if available to click.
  ) {
    clickable = false;  //unable to click now.
    turnsNum++;

    if (nextCardIcon.className === element.target.firstElementChild.className) {
      clickSound();
      clickable = true;  //available to click when matched.
      element.target.classList.add(`matched`);
      iconNameArrayIndex++;
      nextCardIcon.className = iconNames[iconNameArrayIndex];
    } else {  //if not matched.
      element.target.classList.add(`show`);
      setTimeout(function () {
        element.target.classList.remove(`show`);
        clickable = true;  //available to click when card hide again.
      }, 550);
    }

    totalTurnsNum.textContent = `Total Turns: ${turnsNum}`;

    if (iconNameArrayIndex === iconNames.length) {
      nextCardIcon.textContent = `Graz!`;
      alert(`you win!!! the total Turns are ${turnsNum}`);
    }
  }
});