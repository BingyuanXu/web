class TransactionList {
  constructor() {
    this.incomeList = [];
    this.expenseList = [];
    this.id = 0;
    this.totalIncome = 0;
    this.totalExpenses = 0;
  }

  addNewTransaction(description, amount) {
    if (amount >= 0) {
      this.incomeList.push(new Transaction(description, amount, this.id++));
    } else {
      this.expenseList.push(new Transaction(description, amount, this.id++));
    }

    this.redraw();
  }

  removeTransaction(id) {
    this.incomeList = this.incomeList.filter(ele => ele.id != id);
    this.expenseList = this.expenseList.filter(ele => ele.id != id);
    this.redraw();
  }

  incomeListRedraw() {
    let incomeListItems = ``;
    incomeListDiv.innerHTML = ``;
    this.totalIncome = 0;

    for (let ele of this.incomeList) {
      incomeListItems +=
        `<div class="item" data-transaction-id="${ele.id}">
            <div class="item__description">${ele.description}</div>
            <div class="right">
              <div class="item__value">+ $${(parseFloat(ele.amount).toFixed(2))}</div>
              <div class="item__delete">
                <button class="item__delete--btn">
                  <i class="ion-ios-close-outline"></i>
                </button>
              </div>
            </div>
            <div class="item__date"> ${ele.date}</div>
          </div>`;

      this.totalIncome += parseFloat(ele.amount);
    }

    incomeListDiv.insertAdjacentHTML(`beforeend`, `${incomeListItems}`);
  }

  expenseListRedraw() {
    let expenseListItems = ``;
    expensesListDiv.innerHTML = ``;
    this.totalExpenses = 0;

    for (let ele of this.expenseList) {
      expenseListItems +=
        ` <div class="item" data-transaction-id="${ele.id}">
              <div class="item__description">${ele.description}</div>
              <div class="right">
                <div class="item__value">- $${parseFloat(- ele.amount).toFixed(2)}</div>
                <div class="item__percentage">${Math.round((- ele.amount / this.totalIncome) * 100)}%</div>
                <div class="item__delete">
                  <button class="item__delete--btn">
                    <i class="ion-ios-close-outline"></i>
                  </button>
                </div>
              </div>
              <div class="item__date">${ele.date}</div>
            </div>`;

      this.totalExpenses -= parseFloat(ele.amount);
    }

    expensesListDiv.insertAdjacentHTML(`beforeend`, `${expenseListItems}`);
  }

  headerRedraw() {
    budgetTitleMonth.textContent = moment().format('MMMM YYYY');
    budgetIncomeValue.textContent = `+ $${this.totalIncome.toFixed(2)}`;
    budgetExpensesValue.textContent = `- $${this.totalExpenses.toFixed(2)}`;
    budgetExpensesPercentage.textContent = `${this.totalExpenses === 0 ? 0 : Math.round((this.totalExpenses / this.totalIncome) * 100)}%`;

    if (this.totalIncome - this.totalExpenses >= 0) {
      budgetValue.innerHTML = `+ $${(this.totalIncome - this.totalExpenses).toFixed(2)}`;
    } else {
      budgetValue.innerHTML = `- $${(this.totalExpenses - this.totalIncome).toFixed(2)}`;
    }
  }

  redraw() {
    this.incomeListRedraw();
    this.expenseListRedraw();
    this.headerRedraw();
  }
}

class Transaction {
  constructor(description, amount, id) {
    this.description = description;
    this.amount = amount;
    this.id = id;
    this.date = moment().format("MMM. Do, YYYY");
  }
}

const addDescription = document.querySelector(`.add__description`);
const addValue = document.querySelector(`.add__value`);
const submitButton = document.querySelector(`i`);
const incomeListDiv = document.querySelector(`.income__list`);
const expensesListDiv = document.querySelector(`.expenses__list`);
const budgetTitleMonth = document.querySelector(`.budget__title--month`);
const budgetIncomeValue = document.querySelector(`.budget__income--value`);
const budgetExpensesValue = document.querySelector(`.budget__expenses--value`);
const budgetValue = document.querySelector(`.budget__value`);
const listContainer = document.querySelector(`.container`);
const budgetExpensesPercentage = document.querySelector(`.budget__expenses--percentage`);
const newTransactionList = new TransactionList();

newTransactionList.redraw();

submitButton.addEventListener(`click`, function () {
  if (addDescription.value !== `` && addValue.value !== ``) {
    newTransactionList.addNewTransaction(addDescription.value, addValue.value);
    addDescription.value = ``;
    addValue.value = ``;
  }
});

listContainer.addEventListener(`click`, function (event) {
  if (event.target.className === `ion-ios-close-outline`) {
    const targetList = event.target.closest(`.item`);
    newTransactionList.removeTransaction(targetList.dataset.transactionId);
  }
});